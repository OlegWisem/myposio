module.exports = {
  secretOrKey: 'secret'
};
