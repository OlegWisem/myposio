import React from 'react';

export default () => {
  return (
    <div>
      <div className="loader" id="loader-1" />
    </div>
  );
};
